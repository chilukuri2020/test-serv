---
title: "Common API reference"
symbol_kind: "intro"
decl_name: "mg_http.h"
items:
  - { name: mg_connect_ws.md }
  - { name: mg_connect_ws_opt.md }
  - { name: mg_http_is_authorized.md }
  - { name: mg_http_send_digest_auth_request.md }
  - { name: mg_printf_websocket_frame.md }
  - { name: mg_send_websocket_frame.md }
  - { name: mg_send_websocket_framev.md }
  - { name: mg_send_websocket_handshake.md }
  - { name: mg_send_websocket_handshake2.md }
  - { name: mg_send_websocket_handshake3.md }
  - { name: mg_send_websocket_handshake3v.md }
  - { name: mg_set_protocol_http_websocket.md }
  - { name: mg_url_decode.md }
  - { name: struct_http_message.md }
  - { name: struct_mg_http_multipart_part.md }
  - { name: struct_mg_ssi_call_ctx.md }
  - { name: struct_websocket_message.md }
---



